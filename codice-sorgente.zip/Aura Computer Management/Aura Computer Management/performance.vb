﻿Public Class performance
    Dim cpu, ram As Integer

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label_ram.Click

    End Sub

    Private Sub performance_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TimerCPU.Start()
        TimerRAM.Start()
    End Sub

    Private Sub TimerCPU_Tick(sender As Object, e As EventArgs) Handles TimerCPU.Tick
        cpu = PerformanceCounterCPU.NextValue
        ram = PerformanceCounterRAM.NextValue
    End Sub

    Private Sub TimerRAM_Tick(sender As Object, e As EventArgs) Handles TimerRAM.Tick
        If ProgressBarRAM.Value < cpu Then
            ProgressBarRAM.Value += 1
        ElseIf ProgressBarRAM.Value > cpu Then
            ProgressBarRAM.Value -= 1
        End If
        If ProgressBarCPU.Value < ram Then
            ProgressBarCPU.Value += 1
        ElseIf ProgressBarCPU.Value > ram Then
            ProgressBarCPU.Value -= 1
        End If
        Label_cpu.Text = ProgressBarCPU.Value & "%"
        Label_ram.Text = ProgressBarRAM.Value & "%"

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        If 75 > cpu Then
            MsgBox("La tua CPU (processore) sta lavorando un pò duramente... Perfavore chiudi i processi inutili e lascia riposare il PC per un pò.")
        ElseIf 90 > ram Then
            MsgBox("La tua memoria RAM sta lavorando un pò duramente... è consigliabile riavviare il PC.")
        Else : MsgBox("Tutto apposto! :D")
        End If
    End Sub
End Class