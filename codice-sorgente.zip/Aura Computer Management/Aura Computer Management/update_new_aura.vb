﻿Imports System.Diagnostics
Imports System.IO
Public Class update_new_aura

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub update_new_aura_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Process.Start("https://aurastudioitalia.it")
    End Sub
End Class