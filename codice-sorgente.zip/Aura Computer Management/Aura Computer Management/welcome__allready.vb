﻿Public Class welcome__allready

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Application.Restart()
    End Sub

    Private Sub welcome__allready_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class