﻿Imports System.IO
Public Class Loading
    Dim o As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        o += 1
        Select Case o
            Case 1
                If My.Computer.FileSystem.DirectoryExists(Application.StartupPath & "\Settings") Then
                    dashboard.Show()
                    Me.Close()
                    Me.Hide()
                Else
                    welcome.Show()
                    Me.Close()
                    Me.Hide()
                End If
        End Select
    End Sub
End Class
