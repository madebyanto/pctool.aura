﻿Public Class welcome

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        welcome__github.Show()
        Me.Close()
        Me.Hide()
    End Sub
End Class