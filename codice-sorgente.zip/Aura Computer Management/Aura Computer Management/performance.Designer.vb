﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class performance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ProgressBarCPU = New System.Windows.Forms.ProgressBar()
        Me.ProgressBarRAM = New System.Windows.Forms.ProgressBar()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label_cpu = New System.Windows.Forms.Label()
        Me.Label_ram = New System.Windows.Forms.Label()
        Me.TimerCPU = New System.Windows.Forms.Timer(Me.components)
        Me.TimerRAM = New System.Windows.Forms.Timer(Me.components)
        Me.PerformanceCounterCPU = New System.Diagnostics.PerformanceCounter()
        Me.PerformanceCounterRAM = New System.Diagnostics.PerformanceCounter()
        Me.Label7 = New System.Windows.Forms.Label()
        CType(Me.PerformanceCounterCPU, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PerformanceCounterRAM, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(13, 31)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(135, 21)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Processore in uso:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(13, 137)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(177, 21)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Memoria di RAM in uso:"
        '
        'ProgressBarCPU
        '
        Me.ProgressBarCPU.Location = New System.Drawing.Point(49, 66)
        Me.ProgressBarCPU.Name = "ProgressBarCPU"
        Me.ProgressBarCPU.Size = New System.Drawing.Size(324, 23)
        Me.ProgressBarCPU.TabIndex = 3
        '
        'ProgressBarRAM
        '
        Me.ProgressBarRAM.Location = New System.Drawing.Point(49, 183)
        Me.ProgressBarRAM.Name = "ProgressBarRAM"
        Me.ProgressBarRAM.Size = New System.Drawing.Size(324, 23)
        Me.ProgressBarRAM.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.Blue
        Me.Label3.Location = New System.Drawing.Point(11, 66)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 21)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "0%"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Red
        Me.Label4.Location = New System.Drawing.Point(382, 66)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 21)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "100%"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Blue
        Me.Label5.Location = New System.Drawing.Point(11, 185)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(32, 21)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "0%"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(382, 185)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(50, 21)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "100%"
        '
        'Label_cpu
        '
        Me.Label_cpu.AutoSize = True
        Me.Label_cpu.BackColor = System.Drawing.Color.Transparent
        Me.Label_cpu.ForeColor = System.Drawing.Color.Black
        Me.Label_cpu.Location = New System.Drawing.Point(205, 42)
        Me.Label_cpu.Name = "Label_cpu"
        Me.Label_cpu.Size = New System.Drawing.Size(17, 21)
        Me.Label_cpu.TabIndex = 9
        Me.Label_cpu.Text = "?"
        '
        'Label_ram
        '
        Me.Label_ram.AutoSize = True
        Me.Label_ram.BackColor = System.Drawing.Color.Transparent
        Me.Label_ram.ForeColor = System.Drawing.Color.Black
        Me.Label_ram.Location = New System.Drawing.Point(205, 159)
        Me.Label_ram.Name = "Label_ram"
        Me.Label_ram.Size = New System.Drawing.Size(17, 21)
        Me.Label_ram.TabIndex = 10
        Me.Label_ram.Text = "?"
        '
        'TimerCPU
        '
        '
        'TimerRAM
        '
        '
        'PerformanceCounterCPU
        '
        Me.PerformanceCounterCPU.CategoryName = "Processore"
        Me.PerformanceCounterCPU.CounterName = "% Tempo processore"
        Me.PerformanceCounterCPU.InstanceName = "_Total"
        '
        'PerformanceCounterRAM
        '
        Me.PerformanceCounterRAM.CategoryName = "Memoria"
        Me.PerformanceCounterRAM.CounterName = "% Byte vincolati in uso"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(182, 378)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(0, 21)
        Me.Label7.TabIndex = 11
        '
        'performance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(435, 422)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label_ram)
        Me.Controls.Add(Me.Label_cpu)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ProgressBarRAM)
        Me.Controls.Add(Me.ProgressBarCPU)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.White
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "performance"
        Me.Text = "Dashboard > "
        CType(Me.PerformanceCounterCPU, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PerformanceCounterRAM, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ProgressBarCPU As System.Windows.Forms.ProgressBar
    Friend WithEvents ProgressBarRAM As System.Windows.Forms.ProgressBar
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label_cpu As System.Windows.Forms.Label
    Friend WithEvents Label_ram As System.Windows.Forms.Label
    Friend WithEvents TimerCPU As System.Windows.Forms.Timer
    Friend WithEvents TimerRAM As System.Windows.Forms.Timer
    Friend WithEvents PerformanceCounterCPU As System.Diagnostics.PerformanceCounter
    Friend WithEvents PerformanceCounterRAM As System.Diagnostics.PerformanceCounter
    Friend WithEvents Label7 As System.Windows.Forms.Label
End Class
