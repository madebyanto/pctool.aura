﻿Imports System.IO
Public Class welcome__amoment
    Dim a As Integer

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        a += 1
        Select Case a
            Case 1
                My.Computer.FileSystem.CreateDirectory(Application.StartupPath & "\Settings")
                welcome__allready.Show()
                Me.Close()
                Me.Hide()
        End Select
    End Sub

    Private Sub welcome__amoment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class