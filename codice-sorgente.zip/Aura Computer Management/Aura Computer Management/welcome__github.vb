﻿Public Class welcome__github

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub


    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        welcome__betanotify.Show()
        Me.Close()
        Me.Hide()
    End Sub
End Class