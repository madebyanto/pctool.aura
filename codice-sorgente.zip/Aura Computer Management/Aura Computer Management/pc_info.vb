﻿Public Class pc_info
    Dim IP As System.Net.IPHostEntry = System.Net.Dns.GetHostByName(System.Net.Dns.GetHostName)

    Private Sub pc_info_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Text = My.Computer.Name
        TextBox2.Text = My.Computer.Info.OSFullName
        TextBox3.Text = My.Computer.Info.TotalPhysicalMemory & " Byte"
        TextBox4.Text = My.Computer.Screen.WorkingArea.ToString
        TextBox5.Text = My.Computer.Info.AvailablePhysicalMemory & " Byte"
        TextBox6.Text = My.Computer.Screen.DeviceName
        TextBox7.Text = IP.AddressList.GetValue(0).ToString
    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox1.Text = My.Computer.Name
        TextBox2.Text = My.Computer.Info.OSFullName
        TextBox3.Text = My.Computer.Info.TotalPhysicalMemory & " Byte"
        TextBox4.Text = My.Computer.Screen.WorkingArea.ToString
        TextBox5.Text = My.Computer.Info.AvailablePhysicalMemory & " Byte"
        TextBox6.Text = My.Computer.Screen.DeviceName
        TextBox7.Text = IP.AddressList.GetValue(0).ToString
    End Sub
End Class